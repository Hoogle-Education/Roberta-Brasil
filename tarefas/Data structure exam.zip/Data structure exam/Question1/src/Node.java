public class Node {
  
  CPUJob job;
  Node next;

  public Node(CPUJob job){
    this.job = job;
  }

}
