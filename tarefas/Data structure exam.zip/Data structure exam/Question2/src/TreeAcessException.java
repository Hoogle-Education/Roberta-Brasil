public class TreeAcessException extends RuntimeException{

}