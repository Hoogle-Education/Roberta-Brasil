

public class Philosopher extends Thread implements Comparable<Object> {
    
    Semaphore [] chopsticks;
    int id; 
    Semaphore deadlockDetector;

    public Philosopher(int id, Semaphore[] chopsticks, Semaphore deadlockDetector)
    {
        this.id = id;
        this.chopsticks = chopsticks;
        this.deadlockDetector = deadlockDetector;
    }

    @Override
    public void run() {
        

        while(true){
            System.out.println("Philosopher number: " + id +  " is hungry. Now they will pick up chopsticks");
            
            // DEADLOCK CAN OCCUR HERE!
            chopsticks[id].acquire();
            deadlockDetector.acquireDeadlockCheck(this); // this checks that a philospher has 1 chopstick

            chopsticks[(id+1)%chopsticks.length].acquire();
            deadlockDetector.releaseDeadlockCheck(this); // this checks they got the second chopstick
            // if they didn't get the second chopstick then we may be in deadlock
            
            // simulate eating
            System.out.println("Philosopher "  + id+" is eating");
            try{
                Thread.sleep(2);
            } catch(InterruptedException e){}


            // release the chopsticks
            chopsticks[id].release();
            chopsticks[(id+1)%chopsticks.length].release();        


            // philosopher will now take a break
            System.out.println("Philosopher " + id +" is full and will go for a nap");
            try{
                Thread.sleep(2);
            } catch(InterruptedException e){}
        }
        

    }

    // we need to compareTo method for the priority queue
    // the queue is ordered based off of philsopher id
    public int compareTo(Object ph)
    {    
        Philosopher philosopher = (Philosopher) ph;
        return this.id - philosopher.id; 
    }
}
