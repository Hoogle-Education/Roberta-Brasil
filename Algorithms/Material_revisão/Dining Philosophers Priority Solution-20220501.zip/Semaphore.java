import java.util.PriorityQueue;


public class Semaphore{
	int state;
	PriorityQueue philosopherPriority;

	public Semaphore(int size){
		state = size;
	}

	// only use this constructor for the deadlock checker
	public Semaphore(int size, PriorityQueue philosopherPriority)
	{
		this.state=size;
		this.philosopherPriority = philosopherPriority;
	}

	//synchronized ensures this method is only ran by one thread at a single instance of time
	public synchronized void acquire(){
		while(state==0){
			
			try{
				wait(); // any threads running this method must wait until they are notified they can run again
			}catch(InterruptedException e){}
		}
		state--;
	}

	// this method checks that the philosophers are in deadlock by counting down 
	// from the max number. When it equals 0 then we know we are in deadlock.
	public synchronized void acquireDeadlockCheck(Philosopher currentPhilosopher){
		state--;
		philosopherPriority.add(currentPhilosopher);
		/*
		Do something when we know we are in deadlock
		*/
		if(state==0) 
		{
			System.out.println("*******************************\n*******************************\nWe are in deadlock now");
			try{
				Thread.sleep(2000);
			}catch(Exception e){}

			Philosopher lowestPriorityPhilosopher = (Philosopher)philosopherPriority.poll(); // get lowest priority philosopher
			lowestPriorityPhilosopher.chopsticks[lowestPriorityPhilosopher.id].release(); // force them to release their chopstick
			notifyAll(); // tell all waiting philosophers to try get their second chopstick
			try{
				lowestPriorityPhilosopher.sleep(1000);
			}
			catch(Exception e){}
		}
		
	}

	public synchronized void releaseDeadlockCheck(Philosopher ph){
		state++;
		philosopherPriority.remove(ph);
	}

	public synchronized void release(){
		state++;
		notify();
	}

}