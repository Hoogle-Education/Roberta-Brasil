import java.util.PriorityQueue;

class DiningPhilosopherSimulation{
    public static void main(String args[]){
        // using semaphore because chopsticks are the shared resource
        Semaphore chopsticks [] = new Semaphore[5];

        Thread philosophers [] = new Thread[5];
        
        PriorityQueue philosopherPriority = new PriorityQueue<Philosopher>();
        Semaphore deadlockDetector = new Semaphore(5, philosopherPriority);

        for(int i=0; i<chopsticks.length; i++){
            chopsticks[i] = new Semaphore(1);
        }

        for(int i=0; i<philosophers.length; i++){
            philosophers[i] = new Thread(new Philosopher(i, chopsticks,deadlockDetector));
        }

        //now we should start each philosopher thread
        for(int i=0; i<philosophers.length; i++ ){
            philosophers[i].start();
        }

    }
}