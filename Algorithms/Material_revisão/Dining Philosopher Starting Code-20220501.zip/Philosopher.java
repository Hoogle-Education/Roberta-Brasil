public class Philosopher implements Runnable {
    
    Semaphore [] chopsticks;
    int id; 

    public Philosopher(int id, Semaphore[] chopsticks)
    {
        this.id = id;
        this.chopsticks = chopsticks;
    }

    @Override
    public void run() {
        

        while(true){
            System.out.println("Philosopher number: " + id +  " is hungry. Now they will pick up chopsticks");
            
            // DEADLOCK CAN OCCUR HERE!
            chopsticks[id].acquire();
            
            chopsticks[(id+1)%chopsticks.length].acquire();
            
            // simulate eating
            System.out.println("Philosopher "  + id+" is eating");
            try{
                Thread.sleep(2);
            } catch(InterruptedException e){}


            // release the chopsticks
            chopsticks[id].release();
            chopsticks[(id+1)%chopsticks.length].release();        


            // philosopher will now take a break
            System.out.println("Philosopher " + id +" is full and will go for a nap");
            try{
                Thread.sleep(2);
            } catch(InterruptedException e){}
        }
        

    }
}
