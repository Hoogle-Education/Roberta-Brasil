class DiningPhilosopherSimulation{
    public static void main(String args[]){
        // using semaphore because chopsticks are the shared resource
        Semaphore chopsticks [] = new Semaphore[5];

        Thread philosophers [] = new Thread[5];
        
        for(int i=0; i<chopsticks.length; i++){
            chopsticks[i] = new Semaphore(1);
        }

        for(int i=0; i<philosophers.length; i++){
            philosophers[i] = new Thread(new Philosopher(i, chopsticks));
        }

        //now we should start each philosopher thread
        for(int i=0; i<philosophers.length; i++ ){
            philosophers[i].start();
        }

    }
}